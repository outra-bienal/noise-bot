from .settings import *

TESTING = True
