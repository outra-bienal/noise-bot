Noise Bot para a (Outra) 33ª Bienal de Artes de São Paulo

